<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'projukti');

/** MySQL database username */
define('DB_USER', 'projukti_user');

/** MySQL database password */
define('DB_PASSWORD', 'projukti12345');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'bdk_N+v%Ua!+IB$X+;/u o_vuyS5+[ku9UY,kN?H#:%V$|R*`PHA31-*?=.Btt_[');
define('SECURE_AUTH_KEY',  '2pNkQaC[^iw^IP/ltO@VHSp`$Qc-^#1UN3S!_5+kEPNZvL8VW.}Vu95M:xc9]6 b');
define('LOGGED_IN_KEY',    'p(!LNWJXiWQ9Za06:{fFS()=!WOV;|JSfBa&OuBYu3cPE7;vlu,?>Vm|8#*ia#T!');
define('NONCE_KEY',        '=Rc$+&8G/[0K@aru_ap>`zGe(fX+![qLDx,A_F1{W:6Gzl^|Mg|Px&D-0i%ue} r');
define('AUTH_SALT',        'YB|[IFkx_}IIIEDS@@uDKFym<iffF@)+B%Vw2-_ReNs-F=h/Ymk-m3PC7RxDzku;');
define('SECURE_AUTH_SALT', '!d6NXC&#x+3@&l-0l~g[HP%Wx9.i2aW&T@]Pkm25LODj~/3GV|>H0zQ<;{|$@B7B');
define('LOGGED_IN_SALT',   'U!KV;jU!K[O3FK/9Ws^&yBdDh/to qfj_J_4|CFw,XN1C#bW+)~>-JNne2f=Wf7[');
define('NONCE_SALT',       'O_#3k:$l$+5u~VKh;Dv+|>+Saw2!+>,T1+PF]cm(.0|y[9<Jd|  &-XCkwApjohn');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'sharif_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
